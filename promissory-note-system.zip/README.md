# 📄 Promissory Note (PN) System

A complete, self-contained browser demo of a school **Promissory Note workflow** for
St. Peter's College Iligan City. No server, no database, no installs — everything runs in
the browser and data is saved in **localStorage**.

## ▶ How to run

Just double-click `index.html` (or open it in any modern browser). That's it.

Optional — tiny local server (nice for a clean `http://localhost:8137` URL):

```
node server.js
```


> Data (payments, PNs, notifications, enrollments) is stored per-browser.
> Use the **Reset demo data** button on the login page to restore the original dataset.

## 👤 Demo accounts (password = username)

| Account | Password | Role | Situation |
|---|---|---|---|
| `registrar` | `registrar` | Registrar | Approves / rejects filed PNs |
| `accounting` | `accounting` | Accounting / Cashier | Records tuition payments |
| `admin` | `admin` | Admin | **Full power** — every module: PNs, payments, accounts, enrollment, announcements, backup |
| `student1` (Ana Villanueva) | `student1` | Student | **80% paid** → PN-eligible right away |
| `student2` (John Dizon) | `student2` | Student | 44% paid → not eligible yet |
| `student3` (Cathy Alvarez) | `student3` | Student | Exactly **75% paid** → eligible |
| `student4` (Marco Reyes) | `student4` | Student | **Fully paid** → enrolls directly, no PN |

New students can also self-register via **New student sign-up** on the login page.

## 🔄 The flow (75% rule)

1. **Accounting records payments** for a student (amount, OR number, date).
   Tip: record a payment for `student2` to push them past 75% and see the
   automatic "🎉 You reached 75%!" notification.
2. **Student files a PN** — only after paying at least **75% of tuition**.
   The **remaining balance is auto-computed** and becomes the PN amount
   (e.g. ₱30,000 tuition, ₱24,000 paid → PN covers ₱6,000).
   A pending PN still means **enrollment stays locked**.
3. **Registrar gets notified**, reviews the PN (amount, % paid, reason, e-signature,
   promise-to-pay date) and clicks **Approve** or **Reject** (with remarks).
4. The **student is notified right away** (bell icon + toast):
   - ✅ Approved → *"You may now ENROLL and ENLIST your subjects."*
   - ❌ Rejected → shows the reason; the student may file a new PN.
5. The student then **enlists subjects** (max 24 units) and clicks
   **Confirm Enrollment**. The Registrar also receives an enrollment summary.
6. Fully-paid students skip the PN and can enroll immediately.
7. Approved PNs can be **printed** as a formal PN document
   (university header, amounts, promise text, signatures).

## 🛡 Admin console (full power)

Log in as `admin` to get a tabbed console that covers every module:

| Tab | You can … |
|---|---|
| Overview | see all totals, handle pending PNs, jump to any action |
| Promissory Notes | approve / reject pending PNs, print approved PNs, delete any PN record |
| Payments | record tuition payments, print official receipts, delete payment entries |
| Students | create / edit / delete student accounts, change tuition, **unlock enrollment (override)**, manage and confirm subject enlistment, reset passwords |
| Notifications | read the full notification log, send announcements to everyone or a role, clear the log |
| System | export / import a full JSON backup, reset the demo data |

The Admin also receives a copy of every Registrar notification. Every change an Admin
makes takes effect immediately for the affected user (bell notification + unlocked UI).

## 📁 Files

```
promissory-note-system/
├── index.html        ← open this
├── img/logo.png      ← school seal (swap in a higher-res copy anytime, keep the filename)
├── css/style.css     ← theme + print layout for the PN document
├── js/seed.js        ← demo dataset (accounts, payments, subjects)
└── js/app.js         ← all logic: auth, PN flow, notifications, enrollment
```

## ⚙️ Key rules implemented

- `paid ≥ 75%` → PN eligible; below that → blocked (shows how much more is needed).
- Remaining balance auto-calculated at filing time: `tuition − payments`.
- One **pending** PN at a time; after rejection the student may re-file.
- E-signature must exactly match the student's full legal name.
- Promise-to-pay date must be in the future.
- Enrollment unlocks only when: **PN approved** (or tuition fully paid).
- Max subject load: **24 units**; enrollment is locked (read-only) after confirming.
- Every recorded payment can be **printed as an official receipt** (O.R. no., amount in
  words, running balance, cashier signature line) — by the Accounting staff who issued it,
  or by the Registrar from the *Payments & Official Receipts* section.
- A filed PN must attach **ID photos**: the **student school ID (front & back)** and the
  **parent/guardian valid ID (front & back)**. They are shown to the Registrar / Admin and
  printed on the PN document.

## 📝 Notes

- This is a front-end demo: authentication is simple and data lives in one
  browser. For production use, back it with a real database and server-side auth.
